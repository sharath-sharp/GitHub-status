import React, { useState } from "react";
import {
  Button,
  TextInput,
  Tile,
  Grid,
  Column,
  InlineNotification,
  Loading,
  StructuredListWrapper,
  StructuredListHead,
  StructuredListBody,
  StructuredListRow,
  StructuredListCell,
} from "@carbon/react";
import { TrashCan } from "@carbon/icons-react";
import "./App.css";

function App() {
  const [username, setUsername] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");
  const [searchHistory, setSearchHistory] = useState([]);

  // Load search history from localStorage
  React.useEffect(() => {
    const savedHistory = localStorage.getItem("githubStatsHistory");
    if (savedHistory) {
      setSearchHistory(JSON.parse(savedHistory));
    }
  }, []);

  // Set default dates (last 7 days)
  React.useEffect(() => {
    const today = new Date();
    const lastWeek = new Date();
    lastWeek.setDate(today.getDate() - 7);

    setToDate(today.toISOString().split("T")[0]);
    setFromDate(lastWeek.toISOString().split("T")[0]);
  }, []);

  // Save search history to localStorage
  const saveToHistory = (searchData) => {
    const historyItem = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      ...searchData,
    };

    const updatedHistory = [historyItem, ...searchHistory].slice(0, 10);
    setSearchHistory(updatedHistory);
    localStorage.setItem("githubStatsHistory", JSON.stringify(updatedHistory));
  };

  // Delete history item
  const deleteHistoryItem = (id) => {
    const updatedHistory = searchHistory.filter((item) => item.id !== id);
    setSearchHistory(updatedHistory);
    localStorage.setItem("githubStatsHistory", JSON.stringify(updatedHistory));
  };

  // Clear all history
  const clearAllHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem("githubStatsHistory");
  };

  const setQuickDateRange = (days) => {
    const today = new Date();
    const pastDate = new Date();

    if (days === 180) {
      pastDate.setMonth(today.getMonth() - 6);
    } else {
      pastDate.setDate(today.getDate() - days);
    }

    setToDate(today.toISOString().split("T")[0]);
    setFromDate(pastDate.toISOString().split("T")[0]);
  };

  const fetchPRCount = async (username, startDate) => {
    try {
      const query = `author:${username} type:pr created:>=${startDate.split("T")[0]}`;
      const response = await fetch(
        `https://api.github.com/search/issues?q=${encodeURIComponent(query)}`,
        {
          headers: {
            Accept: "application/vnd.github.v3+json",
          },
        },
      );

      if (!response.ok) {
        throw new Error(`GitHub API error: ${response.status}`);
      }

      const data = await response.json();
      return data.total_count;
    } catch (err) {
      throw new Error(`Failed to fetch PR count: ${err.message}`);
    }
  };

  const fetchCommitCount = async (username, startDate, endDate) => {
    try {
      const reposResponse = await fetch(
        `https://api.github.com/search/commits?q=author:${username}+committer-date:2021-01-01..2026-01-31`,
        // `https://api.github.com/users/${username}/repos?per_page=100`,
        {
          headers: {
            Accept: "application/vnd.github.v3+json",
          },
        },
      );
      console.log("reposResponse",reposResponse)
      if (!reposResponse.ok) {
        throw new Error(`GitHub API error: ${reposResponse.status}`);
      }

      const repos = await reposResponse.json();
      let totalCommits = 0;

      for (const repo of repos) {
        try {
          const commitsResponse = await fetch(
            `https://api.github.com/repos/${username}/${repo.name}/commits?author=${username}&since=${startDate}&until=${endDate}&per_page=100`,
            {
              headers: {
                Accept: "application/vnd.github.v3+json",
              },
            },
          );

          if (commitsResponse.ok) {
            const commits = await commitsResponse.json();
            totalCommits += commits.length;
          }
        } catch (err) {
          console.warn(`Failed to fetch commits for ${repo.name}:`, err);
        }
      }

      return totalCommits;
    } catch (err) {
      throw new Error(`Failed to fetch commit count: ${err.message}`);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!username.trim()) {
      setError("Please enter a GitHub username");
      return;
    }

    if (!fromDate || !toDate) {
      setError("Please select both from and to dates");
      return;
    }

    const from = new Date(fromDate);
    const to = new Date(toDate);

    if (from > to) {
      setError("From date must be before To date");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const startISO = new Date(fromDate).toISOString();
      const endISO = new Date(toDate).toISOString();

      const [prCount, commitCount] = await Promise.all([
        fetchPRCount(username, startISO),
        fetchCommitCount(username, startISO, endISO)
      ]);

      const daysDiff = Math.ceil((to - from) / (1000 * 60 * 60 * 24));

      const searchData = {
        username,
        days: daysDiff,
        prCount,
        commitCount,
        startDate: from.toLocaleDateString(),
        endDate: to.toLocaleDateString(),
        fromDate,
        toDate,
      };

      setResults(searchData);
      saveToHistory(searchData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="carbon-app">
      <Grid className="app-container">
        <Column lg={16} md={8} sm={4}>
          <div className="app-header">
            <h1>GitHub Stats Tracker</h1>
            <p className="subtitle">
              Track Pull Requests and Commits for any GitHub user
            </p>
          </div>

          <Tile className="form-tile">
            <form onSubmit={handleSubmit}>
              <div className="form-section">
                <TextInput
                  id="username"
                  labelText="GitHub Username"
                  placeholder="Enter GitHub username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={loading}
                />
              </div>

              <div className="quick-select-section">
                <p className="quick-label">Quick Select:</p>
                <div className="quick-buttons-carbon">
                  <Button
                    kind="tertiary"
                    size="sm"
                    onClick={() => setQuickDateRange(7)}
                    disabled={loading}
                  >
                    Last 7 Days
                  </Button>
                  <Button
                    kind="tertiary"
                    size="sm"
                    onClick={() => setQuickDateRange(30)}
                    disabled={loading}
                  >
                    Last 30 Days
                  </Button>
                  <Button
                    kind="tertiary"
                    size="sm"
                    onClick={() => setQuickDateRange(180)}
                    disabled={loading}
                  >
                    Last 6 Months
                  </Button>
                </div>
              </div>

              <div className="date-picker-section">
                <div className="date-input-wrapper">
                  <label htmlFor="from-date-input" className="cds--label">
                    From Date
                  </label>
                  <input
                    type="date"
                    id="from-date-input"
                    className="cds--text-input"
                    value={fromDate}
                    onChange={(e) => setFromDate(e.target.value)}
                    disabled={loading}
                    max={toDate || undefined}
                  />
                </div>

                <div className="date-input-wrapper">
                  <label htmlFor="to-date-input" className="cds--label">
                    To Date
                  </label>
                  <input
                    type="date"
                    id="to-date-input"
                    className="cds--text-input"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    disabled={loading}
                    min={fromDate || undefined}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="submit-button"
              >
                {loading ? "Fetching Stats..." : "Get Stats"}
              </Button>
            </form>
          </Tile>

          {loading && (
            <div className="loading-container">
              <Loading
                description="Fetching GitHub stats..."
                withOverlay={false}
              />
            </div>
          )}

          {error && (
            <InlineNotification
              kind="error"
              title="Error"
              subtitle={error}
              onCloseButtonClick={() => setError("")}
              className="error-notification"
            />
          )}

          {results && (
            <Tile className="results-tile">
              <h2>Results for @{results.username}</h2>
              <p className="date-range-text">
                {results.startDate} - {results.endDate} ({results.days} days)
              </p>

              <Grid className="stats-grid-carbon">
                <Column lg={8} md={4} sm={4}>
                  <Tile className="stat-tile">
                    <div className="stat-icon">📝</div>
                    <div className="stat-value">{results.prCount}</div>
                    <div className="stat-label">Pull Requests</div>
                  </Tile>
                </Column>

                <Column lg={8} md={4} sm={4}>
                  <Tile className="stat-tile">
                    <div className="stat-icon">💻</div>
                    <div className="stat-value">{results.commitCount}</div>
                    <div className="stat-label">Commits</div>
                  </Tile>
                </Column>
              </Grid>
            </Tile>
          )}

          {searchHistory.length > 0 && (
            <Tile className="history-tile">
              <div className="history-header-carbon">
                <h2>Search History</h2>
                <Button
                  kind="danger--tertiary"
                  size="sm"
                  onClick={clearAllHistory}
                >
                  Clear All
                </Button>
              </div>

              <StructuredListWrapper>
                <StructuredListHead>
                  <StructuredListRow head>
                    <StructuredListCell head>User</StructuredListCell>
                    <StructuredListCell head>Date Range</StructuredListCell>
                    <StructuredListCell head>PRs</StructuredListCell>
                    <StructuredListCell head>Commits</StructuredListCell>
                    <StructuredListCell head>Action</StructuredListCell>
                  </StructuredListRow>
                </StructuredListHead>
                <StructuredListBody>
                  {searchHistory.map((item) => (
                    <StructuredListRow key={item.id}>
                      <StructuredListCell>
                        <strong>@{item.username}</strong>
                        <br />
                        <small>
                          {new Date(item.timestamp).toLocaleString()}
                        </small>
                      </StructuredListCell>
                      <StructuredListCell>
                        {item.startDate} - {item.endDate}
                        <br />
                        <small>({item.days} days)</small>
                      </StructuredListCell>
                      <StructuredListCell>{item.prCount}</StructuredListCell>
                      <StructuredListCell>
                        {item.commitCount}
                      </StructuredListCell>
                      <StructuredListCell>
                        <Button
                          kind="danger--ghost"
                          size="sm"
                          hasIconOnly
                          renderIcon={TrashCan}
                          iconDescription="Delete"
                          onClick={() => deleteHistoryItem(item.id)}
                        />
                      </StructuredListCell>
                    </StructuredListRow>
                  ))}
                </StructuredListBody>
              </StructuredListWrapper>
            </Tile>
          )}
        </Column>
      </Grid>
    </div>
  );
}

export default App;

// Made with Bob
